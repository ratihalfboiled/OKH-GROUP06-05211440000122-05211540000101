/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tsp.genetika.algoritma;
import java.io.*;
import java.util.*;
import java.io.FileWriter;


/**
 *
 * @author GP62MVR 7RF
 */
public class TSP_GA {
    
    public static void main(String[] args) throws IOException {
     final long startTime = System.currentTimeMillis();
     
     
      String Data = "D:\\Kuliah\\Optimasi Kombinasi Heuristik\\datasets\\hiddeninstance1.csv";
      
      //
       Input reader = new Input();
        reader.read(Data);
        //reader.print();
        System.out.println("City : " + reader.coor1.size());
        
        //create city in TourManager
        int index = 0;
        while (index < reader.coor1.size()) {
            City city = new City(reader.coor1.get(index), reader.coor2.get(index));
            TourManager.addCity(city);
            index++;
        }
     
        // Initialize population
        Population pop = new Population(500, true);
        System.out.println("Initial distance: " + pop.getFittest().getDistance());

        // Evolve population for 100 generations
        pop = GA.evolvePopulation(pop);
        for (int i = 0; i < 1000; i++) {
            pop = GA.evolvePopulation(pop);
        }

        // Print final results
        System.out.println("Finished");
        System.out.println("Final distance: " + pop.getFittest().getDistance());
        System.out.println("Solution:");
        System.out.println(pop.getFittest());
        
        //menyimpan hasil solusi kedalam bentuk csv
        //FileWriter wr = new FileWriter("D:solusi.csv");
        //wr.write(new Integer(pop.getFittest()));
        
        //Cetak Running Time
        long endTime   = System.currentTimeMillis();
        long totalTime = endTime - startTime;
        System.out.println("Running Time :" + totalTime + " Miliseconds");
    
    }
}
