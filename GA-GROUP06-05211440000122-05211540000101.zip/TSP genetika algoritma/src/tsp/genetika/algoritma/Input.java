/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tsp.genetika.algoritma;
import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author GP62MVR 7RF
 */
class Input {

    ArrayList <Integer> coor1 = new ArrayList <Integer>();    
    ArrayList <Integer> coor2 = new ArrayList <Integer>();
    String str;
    BufferedReader br;
    
    public void read (String namaFile) {
            try {
                br = new BufferedReader(new FileReader(namaFile));
                br.readLine();
                
                while((str = br.readLine()) != null){
                    String[] coor = str.split(",");
                    coor1.add(Integer.parseInt(coor[0]));
                    coor2.add(Integer.parseInt(coor[1]));
                }
            } 
            catch (FileNotFoundException ex) {
                Logger.getLogger(Input.class.getName()).log(Level.SEVERE, null, ex);
            }
            catch (IOException ex) {
                Logger.getLogger(Input.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    
   
}
