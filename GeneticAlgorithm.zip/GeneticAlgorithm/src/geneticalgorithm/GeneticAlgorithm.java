/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geneticalgorithm;

import java.io.*;
import java.util.*;

public class GeneticAlgorithm {

    /*private static ArrayList<String> towns;
    private static double[][] coords;
    private static int size;*/
    private static int size;

    public static void main(String[] args) throws Exception {
        String Data = "D:/dataset/small1.csv";

        //
        Input reader = new Input();
        reader.read(Data);
        System.out.println("City : " + reader.coor1.size());

        //adding city in TourManager
        int index = 0;
        while (index < reader.coor1.size()) {
            City city = new City(reader.coor1.get(index), reader.coor2.get(index));
            TourManager.addCity(city);
            index++;
        }

        Population pop = new Population(5, true);

        System.out.println(
                "Initial distance: " + pop.getFittest().getDistance());

        // Evolve population for 100 generations
        pop = GA.evolvePopulation(pop);
        for (int i = 0; i < 100; i++) {
            pop = GA.evolvePopulation(pop);
        }

        // Print final results
        System.out.println(
                "Finished");
        System.out.println(
                "Final distance: " + pop.getFittest().getDistance());
        System.out.println(
                "Solution:");
        System.out.println(pop.getFittest());
    }
}
